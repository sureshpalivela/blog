# Blog
I have complete my 2nd task of my internship as a full stack web developer.

Title: Blog Application 

I have create a blog app, where user can read and write a blog. And they will share onw thoughts.

Firstly if a new user then it will be register and then login. If it will not register then they can not write blog.

When user  register/login they will be edit their profile be like profile-photo,username and password too. And now user can share their onw blog with everyone with title, description and photo.

If user like any author's blog they will fatch that author's all the blogs.

User can edite and delete their onw blog. but can not change other users blog.

And last but not the least in the app have a beautiful About page and footer. And in the about page I have mention all my social media link So that User can recognize us.

linkdin link- https://www.linkedin.com/posts/aryan-patel-97623127b_i-have-complete-my-2nd-task-of-my-internship-activity-7093487787240304640-Az0N?utm_source=share&utm_medium=member_desktop
