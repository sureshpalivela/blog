import "./Footer.css"

export default function Footer() {
  return (
    <div>
        <div class className="Footer">
    <span>© 2023 www.<b>Blog</b>.com. All rights reserved by <b>Blog</b>.</span>
    </div>
    </div>
  )
}
